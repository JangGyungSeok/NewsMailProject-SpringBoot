package com.JKS.TIL1.Services;

public interface CrawlingInterface {

    // 어제자 뉴스 크롤링 로직
    public void crawlingNews();
}