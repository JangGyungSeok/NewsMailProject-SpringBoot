package com.JKS.TIL1.Controllers;

import org.springframework.stereotype.Controller;

@Controller
public class SendMailController {
    
}