package com.JKS.TIL1.Services;

public interface DashBoardInterface {
    public void allNews();
}