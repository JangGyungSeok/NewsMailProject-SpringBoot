package com.JKS.TIL1.Services;

import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.stereotype.Component;

// @Configuration
// @EnableScheduling
public class Test {
    // Timer timer;
    // HelloTask task;

    // public Test(){
    //     timer = new Timer();
    //     task = new HelloTask();

    //     timer.schedule(task, new Date(), 1000);
    // }
}

// @Component
// class HelloTask extends TimerTask{
//     public void run(){
//         System.out.println("task실행이라구");
//     }
// }